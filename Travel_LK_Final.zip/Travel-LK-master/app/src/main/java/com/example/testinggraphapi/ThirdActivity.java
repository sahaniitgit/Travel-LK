package com.example.testinggraphapi;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.res.ResourcesCompat;

import com.google.android.material.imageview.ShapeableImageView;
import com.google.android.material.shape.CornerFamily;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class ThirdActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third);
        DisplayMetrics dm = new DisplayMetrics();
        this.getWindow().getWindowManager().getDefaultDisplay().getMetrics(dm);
        int width = dm.widthPixels;
        LinearLayout layout = findViewById(R.id.linear_layout);
        Button back = findViewById(R.id.button3);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        //getting the information from the previous activity
        Bundle extras = getIntent().getExtras();
        String name = extras.getString("namekey");
        String imageurl = extras.getString("imagekey");
        String info = extras.getString("descriptionkey");
        String distance = extras.getString("distancekey");

        //arraylist which contains location names
        ArrayList<String> locations = new ArrayList<String>();

        //arraylist which contains the image urls of the locations
        ArrayList<String> website = new ArrayList<String>();

        //arraylist which contains the description of the locations
        ArrayList<String> description = new ArrayList<String>();

        //arraylist which contains the distances of the locations
        ArrayList<String> distances = new ArrayList<String>();

        //arraylist which contains the ratings of the locations
        ArrayList<String> ratings = new ArrayList<String>();
        ArrayList<String> names = new ArrayList<String>();
        ArrayList<String> urls = new ArrayList<String>();
        ArrayList<String> distanceslist = new ArrayList<String>();

        locations = extras.getStringArrayList("locations");
        website = extras.getStringArrayList("images");
        description = extras.getStringArrayList("descriptions");
        distances = extras.getStringArrayList("distances");
        ratings = extras.getStringArrayList("ratings");
       names= extras.getStringArrayList("names") !=null ?extras.getStringArrayList("names"):new ArrayList<>();
        urls=extras.getStringArrayList("urls")!=null ?extras.getStringArrayList("urls"):new ArrayList<>();
        distanceslist=extras.getStringArrayList("distanceslist")!=null ?extras.getStringArrayList("distanceslist"):new ArrayList<>();

        //setting the views
        TextView txt = new TextView(ThirdActivity.this);
        TextView txt2 = new TextView(ThirdActivity.this);
        TextView txt3 = new TextView(ThirdActivity.this);
        TextView txt4 = new TextView(ThirdActivity.this);

        ImageView image = new ImageView(ThirdActivity.this);
        TextView empty = new TextView(ThirdActivity.this);
        Button itinerarybtn = new Button(ThirdActivity.this);
        final Typeface typeface1 = ResourcesCompat.getFont(this, R.font.poppins_semibold);
        final Typeface typeface2 = ResourcesCompat.getFont(this, R.font.poppins);
        ShapeableImageView imageView = new ShapeableImageView(ThirdActivity.this);
        imageView.setShapeAppearanceModel(imageView.getShapeAppearanceModel()
                .toBuilder()
                .setAllCorners(CornerFamily.ROUNDED, 70)
                .build());

        itinerarybtn.setText("ADD TO ITINERARY");
        itinerarybtn.setTextColor(Color.parseColor("#304156"));
        itinerarybtn.setBackgroundColor(Color.parseColor("#f1c40f"));
        itinerarybtn.setClickable(true);

        ArrayList<String> finalLocations = locations;
        ArrayList<String> finalDescription = description;
        ArrayList<String> finalDistances = distances;
        ArrayList<String> finalRatings = ratings;
        ArrayList<String> finalWebsite = website;

        ArrayList<String> finalDistanceslist = distanceslist;
        ArrayList<String> finalUrls = urls;
        ArrayList<String> finalNames = names;
        itinerarybtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ShapeableImageView imageView = new ShapeableImageView(ThirdActivity.this);

                Intent activity3Intent = new Intent(getApplicationContext(), SecondActivity.class);

                    if (!finalNames.contains(name)) {
                        finalNames.add(name);
                        finalUrls.add(imageurl);
                        finalDistanceslist.add(distance);

                    }

                activity3Intent.putStringArrayListExtra("names", finalNames);
                activity3Intent.putStringArrayListExtra("urls", finalUrls);
                activity3Intent.putStringArrayListExtra("distanceslist", finalDistanceslist);
                activity3Intent.putStringArrayListExtra("locations", finalLocations);
                activity3Intent.putStringArrayListExtra("descriptions", finalDescription);
                activity3Intent.putStringArrayListExtra("distances", finalDistances);
                activity3Intent.putStringArrayListExtra("ratings", finalRatings);
                activity3Intent.putStringArrayListExtra("images", finalWebsite);

                CharSequence msg = "Added to itinerary";
                Toast.makeText(ThirdActivity.this, msg, Toast.LENGTH_SHORT).show();
                startActivity(activity3Intent);
            }
        });
        txt.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        empty.setHeight(10);
        empty.setText("  ");
        txt.setTextSize(20);
        txt.setTypeface(null, Typeface.BOLD);
        txt.setTextColor(Color.parseColor("#304156"));
        txt.setWidth(width);
        txt.setTypeface(typeface1);
        txt2.setWidth(width);
        txt2.setTextSize(15);
        txt2.setTypeface(typeface2);
        txt2.setTextColor(Color.parseColor("#304156"));
        txt.setText(name);
        txt3.setTextColor(Color.parseColor("#304156"));
        txt3.setText(distance);
        txt3.setTypeface(typeface1);
        //txt4.setText(ratings);

        Picasso.get().load(imageurl).resize(width, 550).into(imageView);

        txt2.setText(info);
        layout.addView(txt);
        layout.addView(empty);
        layout.addView(imageView);
        layout.addView(txt2);
        layout.addView(txt3);
        layout.addView(txt4);
        layout.addView(itinerarybtn);

    }
}