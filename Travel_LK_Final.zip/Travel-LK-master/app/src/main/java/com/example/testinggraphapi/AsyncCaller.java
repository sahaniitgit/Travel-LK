package com.example.testinggraphapi;

import com.example.testinggraphapi.remoteimageanalysis;

import android.os.AsyncTask;

import com.microsoft.azure.cognitiveservices.vision.computervision.ComputerVisionClient;
import com.microsoft.azure.cognitiveservices.vision.computervision.ComputerVisionManager;
import com.microsoft.azure.cognitiveservices.vision.computervision.models.Category;
import com.microsoft.azure.cognitiveservices.vision.computervision.models.ImageAnalysis;
import com.microsoft.azure.cognitiveservices.vision.computervision.models.ImageCaption;
import com.microsoft.azure.cognitiveservices.vision.computervision.models.ImageTag;
import com.microsoft.azure.cognitiveservices.vision.computervision.models.VisualFeatureTypes;
import com.mongodb.Block;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Indexes;

import org.bson.Document;
import org.bson.conversions.Bson;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class AsyncCaller extends AsyncTask {
    static ArrayList<String> tags = new ArrayList<String>();


    @Override
    protected Object doInBackground(Object[] objects) {

        //ComputerVisionClient compVisClient = Authenticate(subscriptionKey, endpoint);
//        remoteimageanalysis.AnalyzeRemoteImage(compVisClient);

        return null;
    }
}
