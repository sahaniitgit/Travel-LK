package com.example.testinggraphapi;


import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.TextView;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.app.NotificationCompatExtras;
import androidx.core.content.res.ResourcesCompat;

import com.google.android.material.imageview.ShapeableImageView;
import com.google.android.material.shape.CornerFamily;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class SecondActivity extends AppCompatActivity {
    ArrayList<String> names = new ArrayList<String>();
    ArrayList<String> urls = new ArrayList<String>();
    ArrayList<String> distanceslist = new ArrayList<String>();
    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        //getting the metrics of the displayed screen
        DisplayMetrics dm = new DisplayMetrics();
        this.getWindow().getWindowManager().getDefaultDisplay().getMetrics(dm);
        int width = dm.widthPixels;
        LinearLayout layout;
        //arraylist which contains location names
        ArrayList<String> locations = new ArrayList<String>();

        //arraylist which contains the image urls of the locations
        ArrayList<String> website = new ArrayList<String>();

        //arraylist which contains the description of the locations
        ArrayList<String> description = new ArrayList<String>();

        //arraylist which contains the distances of the locations
        ArrayList<String> distances = new ArrayList<String>();

        //arraylist which contains the ratings of the locations
        ArrayList<String> ratings = new ArrayList<String>();

        Bundle eex = getIntent().getExtras();
        locations=eex.getStringArrayList("locations");
        website=eex.getStringArrayList("images");
        description=eex.getStringArrayList("descriptions");
        distances=eex.getStringArrayList("distances");
        ratings=eex.getStringArrayList("ratings");


        /*list.add("Crescat Boulevard-Colombo");
        list.add("Ruwanweli Maha seya");
        list.add("Thuparamaya");
        list.add("Ridi Viharaya");
        list.add("Matale");

        website.add("https://cinnamonweb.blob.core.windows.net/cinnamonweb-prd/dining_wellness/Crescat-shopping-exp-1090X610.jpg");
        website.add("https://mapio.net/images-p/25543374.jpg");
        website.add("https://www.attractionsinsrilanka.com/wp-content/uploads/2020/09/Thuparamaya.jpg");
        website.add("https://www.lanka-excursions-holidays.com/uploads/4/0/2/1/40216937/ridigama-1-900_orig.jpg");
        website.add("https://scontent.fcmb9-1.fna.fbcdn.net/v/t1.6435-9/185476893_838474886754383_7292357134745849839_n.jpg?stp=dst-jpg_p720x720&_nc_cat=105&ccb=1-5&_nc_sid=730e14&_nc_ohc=WEoLiDuYtpgAX_vrJdu&_nc_ht=scontent.fcmb9-1.fna&oh=00_AT9UzFafwOPKKtInOMaXaCVel-SO2yqf81OBwuvPuSucDQ&oe=624079DC");

        description.add("Located in Colombo, Crescat Boulevard is one of the best places for Sri Lanka shopping. If you want to explore some of the best local brands, then this place should definitely be on your list. You'll also find a lot of options");
        description.add("RuwanweliseyaRuwanweliseyaRuwanweliseyaRuwanweliseyaRuwanweliseya");
        description.add("ThuparamayaThuparamayaThuparamayaThuparamayaThuparamayaThuparamaya");
        description.add("RidiViharayaRidiViharayaRidiViharayaRidiViharayaRidiViharayaRidiViharaya");
        description.add("matalematale");

        distances.add("25 KM");
        distances.add("40 KM");
        distances.add("35 KM");
        distances.add("50 KM");
        distances.add("55 KM");

        ratings.add("4.5");
        ratings.add("3.5");
        ratings.add("2.5");
        ratings.add("1.5");
        ratings.add("0.5");*/

        layout = findViewById(R.id.linearlayout);
        Button itinerary = findViewById(R.id.button4);
        Bundle extras = getIntent().getExtras();

        if(extras!=null) {
            if (!extras.isEmpty()) {
                names=extras.getStringArrayList("names");
                urls=extras.getStringArrayList("urls");
                distanceslist=extras.getStringArrayList("distanceslist");
                ArrayList<String> finalRatings = ratings;
                itinerary.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent activityIntent = new Intent(SecondActivity.this , ItineraryActivity.class);
                        activityIntent.putStringArrayListExtra("names",names);
                        activityIntent.putStringArrayListExtra("urls",urls);
                        activityIntent.putStringArrayListExtra("distanceslist",distanceslist);
                        activityIntent.putStringArrayListExtra("ratings", finalRatings);

                        startActivity(activityIntent);
                    }
                });
            }
        }

        for (int i = 0; i < locations.size(); i++) {
            RatingBar ratingbar = new RatingBar(this, null, android.R.attr.ratingBarStyleIndicator);
            LinearLayout horizontal = new LinearLayout(this);
            horizontal.setOrientation(LinearLayout.HORIZONTAL);
            LinearLayout vertical = new LinearLayout(this);
            vertical.setOrientation(LinearLayout.VERTICAL);
            CardView cardview = new CardView(SecondActivity.this);
            TextView txt = new TextView(SecondActivity.this);
            TextView distance = new TextView(SecondActivity.this);
            TextView rating= new TextView(SecondActivity.this);
            final Typeface typeface1 = ResourcesCompat.getFont(this, R.font.poppins_semibold);
            final Typeface typeface2 = ResourcesCompat.getFont(this, R.font.poppins);


            ShapeableImageView imageView = new ShapeableImageView(SecondActivity.this);
            Picasso.get().load(website.get(i)).resize(width / 29 * 15, 500).into(imageView);
            imageView.setShapeAppearanceModel(imageView.getShapeAppearanceModel()
                    .toBuilder()
                    .setAllCorners(CornerFamily.ROUNDED, 50)
                    .build());
            vertical.setMinimumWidth(width / 30 * 14);
            vertical.setPadding(10, 10, 10, 10);
            txt.setWidth(width/30*14);
            txt.setHeight(200);
            distance.setTop(800);
            distance.setWidth(width / 30 * 14);
            distance.setHeight(150);
            distance.setTextSize(14);
            distance.setText("Distance: " + distances.get(i));
            distance.setTextColor(Color.parseColor("#304156"));
            distance.setTypeface(null, Typeface.NORMAL);
            distance.setTypeface(typeface2);
            txt.setTextSize(18);
            txt.setText(locations.get(i));
            txt.setTypeface(typeface1);
            txt.setTextColor(Color.parseColor("#304156"));
            txt.setTypeface(typeface1);
            rating.setTextSize(14);
            rating.setText("Rating: "+ratings.get(i));
            rating.setTypeface(null,Typeface.BOLD);
            rating.setTypeface(typeface2);
            rating.setTextColor(Color.parseColor("#304156"));
            vertical.addView(txt);
            vertical.addView(distance);
            vertical.addView(rating);
            horizontal.addView(imageView);
            horizontal.addView(vertical);
            cardview.setCardElevation(450);
            cardview.setRadius(50);
            cardview.addView(horizontal);
            cardview.setContentPadding(0, 0, 0, 12);
            cardview.setCardElevation(30);
            cardview.setId(i);
            cardview.setClickable(true);
            layout.addView(cardview);

            //setting the clickable areas
            ArrayList<String> finalLocations = locations;
            ArrayList<String> finalDistances = distances;
            ArrayList<String> finalDescription = description;
            ArrayList<String> finalWebsite = website;
            ArrayList<String> finalLocations1 = locations;
            ArrayList<String> finalDescription1 = description;
            ArrayList<String> finalDistances1 = distances;
            ArrayList<String> finalRatings1 = ratings;
            ArrayList<String> finalWebsite1 = website;
            cardview.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    int clickedimage = cardview.getId();
                    Intent activity2Intent = new Intent(getApplicationContext(), ThirdActivity.class);
                    activity2Intent.putStringArrayListExtra("names",names);
                    activity2Intent.putStringArrayListExtra("urls",urls);
                    activity2Intent.putStringArrayListExtra("distanceslist",distanceslist);
                    activity2Intent.putStringArrayListExtra("locations", finalLocations1);
                    activity2Intent.putStringArrayListExtra("descriptions", finalDescription1);
                    activity2Intent.putStringArrayListExtra("distances", finalDistances1);
                    activity2Intent.putStringArrayListExtra("ratings", finalRatings1);
                    activity2Intent.putStringArrayListExtra("images", finalWebsite1);
                    activity2Intent.putExtra("namekey", finalLocations.get(clickedimage));
                    activity2Intent.putExtra("imagekey", finalWebsite.get(clickedimage));
                    activity2Intent.putExtra("descriptionkey", finalDescription.get(clickedimage));
                    activity2Intent.putExtra("distancekey", finalDistances.get(clickedimage));
                    startActivity(activity2Intent);
                }
            });
        }
    }
}

