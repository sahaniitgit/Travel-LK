package com.example.testinggraphapi;

import static androidx.core.app.ActivityCompat.requestPermissions;

import android.Manifest;
import android.os.Build;
import android.os.Environment;
import android.widget.Toast;

import androidx.annotation.RequiresApi;

import com.microsoft.azure.cognitiveservices.vision.computervision.ComputerVisionClient;
import com.microsoft.azure.cognitiveservices.vision.computervision.ComputerVisionManager;
import com.microsoft.azure.cognitiveservices.vision.computervision.models.*;
import com.mongodb.Block;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Indexes;
import com.opencsv.CSVReader;

import org.bson.Document;
import org.bson.conversions.Bson;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import java.io.IOException;
import java.io.FileReader;


public class remoteimageanalysis {


    //static String subscriptionKey = "b3269c4593e64cd3aad19ff12eb36a12";
    //static String endpoint = "https://sdgp.cognitiveservices.azure.com/";
    static ArrayList<String> tags = new ArrayList<String>();

    List<String> valList = new ArrayList<>();
    List<ImageSchema>imageListCsv = new ArrayList<>();
    List<ImageSchema> selectedList = new ArrayList<>();

    public remoteimageanalysis(List<String> valList) {
        this.valList = valList;
    }

    public remoteimageanalysis() {
    }

    public void setValList(List<String> valList) {
        this.valList = valList;
    }

    public List<String> getValList() {
        return valList;
    }

    public void imageprocessing() {
        System.out.println("\nAzure Cognitive Services Computer Vision - Java Quickstart Sample");

        ;
        // Create an authenticated Computer Vision client.
        //ComputerVisionClient compVisClient = Authenticate(subscriptionKey, endpoint);

        // Analyze local and remote images
        //AnalyzeRemoteImage(compVisClient);
        String uri = "mongodb://localhost:27017";
        try (MongoClient mongoClient = MongoClients.create(uri)) {
            MongoDatabase database = mongoClient.getDatabase("TravelLK");
            MongoCollection<Document> collection = database.getCollection("LocationDataset");
            collection.createIndex(Indexes.text("tags"));
            ArrayList<String> ids = new ArrayList<String>();
            for (String tag : tags) {
                Bson filter = Filters.text(tag);
                collection.find(filter).forEach((Block<? super Document>) doc -> ids.add(doc.toJson()));

                //collection.find(filter).forEach((Block<? super Document>) doc -> System.out.println(doc.toJson()));


            }
            List myUniqueList = ids.stream().distinct().collect(Collectors.toList());
            for (Object id : myUniqueList) {
                System.out.println(id);
            }

        }

    }

    public ComputerVisionClient Authenticate(String subscriptionKey, String endpoint) {
        return ComputerVisionManager.authenticate(subscriptionKey).withEndpoint(endpoint);
    }

    @RequiresApi(api = Build.VERSION_CODES.Q)
    public void AnalyzeRemoteImage(ComputerVisionClient compVisClient) {
        /*
         * Analyze an image from a URL:

         */

        //MA.vallist
//        String pathToRemoteImage = "https://i.imgur.com/ZdOPBCu.jpg";
        for (int i = 0; i < 5; i++) {
            String pathToRemoteImage = valList.get(i);
            // This list defines the features to be extracted from the image.
            List<VisualFeatureTypes> featuresToExtractFromRemoteImage = new ArrayList<>();
            featuresToExtractFromRemoteImage.add(VisualFeatureTypes.DESCRIPTION);
            featuresToExtractFromRemoteImage.add(VisualFeatureTypes.CATEGORIES);
            featuresToExtractFromRemoteImage.add(VisualFeatureTypes.TAGS);

            System.out.println("\n\nAnalyzing an image from a URL ...");


            try {
                // Call the Computer Vision service and tell it to analyze the loaded image.
                ImageAnalysis analysis = compVisClient.computerVision().analyzeImage().withUrl(pathToRemoteImage)
                        .withVisualFeatures(featuresToExtractFromRemoteImage).execute();

                // Display image captions and confidence values.
                System.out.println("\nCaptions: ");
                for (ImageCaption caption : analysis.description().captions()) {
                    System.out.printf("\'%s\' with confidence %f\n", caption.text(), caption.confidence());
                }

                // Display image category names and confidence values.
                System.out.println("\nCategories: ");
                for (Category category : analysis.categories()) {
                    System.out.printf("\'%s\' with confidence %f\n", category.name(), category.score());
                }

                // Display image tags and confidence values.
                System.out.println("\nTags: ");

                for (ImageTag tag : analysis.tags()) {
                    System.out.printf("\'%s\' with confidence %f\n", tag.name(), tag.confidence());
                    tags.add(tag.name());

                }
                System.out.println("tags are :" + tags);
            } catch (Exception e) {
                System.out.println(e.getMessage());
                System.out.println(pathToRemoteImage);
                e.printStackTrace();
            }
        }
        Set<String> tagSet = new HashSet<>(tags);
        tagSet = tagSet.stream().map(x->x.trim()).collect(Collectors.toSet());
        readfile();
        readcsvfile();

        for(int i=0;i<imageListCsv.size();i++){
            for(int j=0;j<imageListCsv.get(i).getTags().size();j++){
                String temp = imageListCsv.get(i).getTags().get(j);
                if(tagSet.contains(temp)){
                    selectedList.add(imageListCsv.get(i));
                    break;
                }
            }
        }
        //System.out.println("Selected images");
        //selectedList.stream().map(x->x.getName()).forEach(System.out::println);



        //mongodb();
        // List<ImageSchema> imgs = passDataSQL();
        // imgs.stream().map(x->x.getName()).forEach(System.out::println);

    }

    public List<ImageSchema> getImageListCsv(){
        return selectedList;
    }

    private void readfile() {

        try {

            File csvfile = new File(Environment.getExternalStorageDirectory() + "/Location_dataset.csv");
            CSVReader reader = new CSVReader(new FileReader(csvfile.getAbsolutePath()));
            String[] nextLine;
            reader.readNext();
            while ((nextLine = reader.readNext()) != null) {
                // nextLine[] is an array of values from the line
                imageListCsv.add(new ImageSchema(
                        Integer.parseInt(nextLine[0]),
                        nextLine[1],
                        nextLine[2],
                        nextLine[3],
                        Arrays.stream(nextLine[4].split(",")).map(x->x.trim()).collect(Collectors.toList()),
                        nextLine[5],
                        nextLine[6]
                ));
            //System.out.println(nextLine[0] + nextLine[1] + nextLine[2]+ nextLine[3]+nextLine[4]+nextLine[5]+nextLine[6]);
                 }
            //imageListCsv.stream().map(x->x.getName()).forEach(System.out::println);

        } catch (Exception e) {
            e.printStackTrace();

        }

    }


    @RequiresApi(api = Build.VERSION_CODES.Q)
    private void readcsvfile() {
//        MyDatabaseHelper myDatabaseHelper;
//        myDatabaseHelper = new MyDatabaseHelper(this, "Location_DB.db", 0);
//        try {
//            myDatabaseHelper.CheckDatabase();
//        } catch (Exception e) {
//        }
//        try {
//            myDatabaseHelper.OpenDatabase();
//        } catch (Exception e) {
//
//        }
    }

//    public List<ImageSchema> passDataSQL(){
//        List<ImageSchema> images = new ArrayList<>();
//        try{
//            Connection conn = DBConnection.getDBConnection().getConnection();
//            String sql = "SELECT * FROM IMAGES";
//            Statement stm = conn.createStatement();
//            ResultSet rst = stm.executeQuery(sql);
//
//            while(rst.next()){
//                images.add(new ImageSchema(
//                        rst.getString("NAME"),
//                        rst.getString("DESCRIPTION"),
//                        rst.getString("IMAGELINK"),
//                        rst.getString("TAGS")
//                ));
//                System.out.println(rst.getString("name"));
//            }
//        }catch(SQLException | ClassNotFoundException e){
//            e.printStackTrace();
//        }
//        return images;
//    }

//        private static void mongodb () {
//            System.out.println("mongo ");
//            String uri = "mongodb://localhost:27017";
//            try (MongoClient mongoClient = MongoClients.create("mongodb+srv://TRAVELLK:travellk123@cluster0.inqdp.mongodb.net/TravelLK?authSource=admin&replicaSet=atlas-14fy67-shard-0&readPreference=primary&appname=MongoDB%20Compass&ssl=true")) {
//                MongoDatabase database = mongoClient.getDatabase("TravelLK");
//                MongoCollection<Document> collection = database.getCollection("LocationDataset");
//                collection.createIndex(Indexes.text("tags"));
//                ArrayList<String> ids = new ArrayList<String>();
//                for (String tag : tags) {
//                    Bson filter = Filters.text(tag);
//                    collection.find(filter).forEach((Block<? super Document>) doc -> ids.add(doc.toJson()));
//                    //collection.find(filter).forEach((Block<? super Document>) doc -> System.out.println(doc.toJson()));
//
//                }
//                List myUniqueList = ids.stream().distinct().collect(Collectors.toList());
//                for (Object id : myUniqueList) {
//                    System.out.println(id);
//                }
//
//
//            }
//        }


}


