package com.example.testinggraphapi;

import java.util.List;

public class ImageSchema {
    private int id;
    private String name;
    private String description;
    private String imageLink;
    private List<String> tags;
    private String rating;
    private String distance;

    public ImageSchema(int id, String name, String description, String imageLink, List<String> tags,
                       String rating, String distance) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.imageLink = imageLink;
        this.tags = tags;
        this.rating =rating;
        this.distance = distance;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getRating() {
        return rating;
    }

    public void setRating(String rating) {
        this.rating = rating;
    }

    public String getDistance() {
        return distance;
    }

    public void setDistance(String distance) {
        this.distance = distance;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getImageLink() {
        return imageLink;
    }

    public void setImageLink(String imageLink) {
        this.imageLink = imageLink;
    }

    public List<String> getTags() {
        return tags;
    }

    public void setTags(List<String> tags) {
        this.tags = tags;
    }
}
