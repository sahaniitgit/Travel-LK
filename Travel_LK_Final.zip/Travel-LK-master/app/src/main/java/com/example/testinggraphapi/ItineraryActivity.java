package com.example.testinggraphapi;

import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.content.res.ResourcesCompat;

import com.google.android.material.imageview.ShapeableImageView;
import com.google.android.material.shape.CornerFamily;
import com.squareup.picasso.Picasso;

public class ItineraryActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        DisplayMetrics dm = new DisplayMetrics();
        this.getWindow().getWindowManager().getDefaultDisplay().getMetrics(dm);
        int width = dm.widthPixels;
        setContentView(R.layout.activity_itinerary);
        LinearLayout layout;
        layout=findViewById(R.id.linear_layout1);
        Button back=findViewById(R.id.button3);
        Bundle extras= getIntent().getExtras();
        for (int i = 0; i < extras.getStringArrayList("names").size(); i++){
            TextView txt=new TextView(ItineraryActivity.this);
            LinearLayout vertical = new LinearLayout(ItineraryActivity.this);
            vertical.setOrientation(LinearLayout.VERTICAL);
            LinearLayout horizontal = new LinearLayout(ItineraryActivity.this);
            horizontal.setOrientation(LinearLayout.HORIZONTAL);
            CardView cardView=new CardView(ItineraryActivity.this);
            TextView distance = new TextView(ItineraryActivity.this);
            final Typeface typeface1 = ResourcesCompat.getFont(this, R.font.poppins_semibold);
            final Typeface typeface2 = ResourcesCompat.getFont(this, R.font.poppins);

            ShapeableImageView imageView = new ShapeableImageView(ItineraryActivity.this);
            Picasso.get().load(extras.getStringArrayList("urls").get(i)).resize(width / 30 * 15, 450).into(imageView);
            imageView.setShapeAppearanceModel(imageView.getShapeAppearanceModel()
                    .toBuilder()
                    .setAllCorners(CornerFamily.ROUNDED, 50)
                    .build());
            vertical.setMinimumWidth(width / 30 * 14);
            vertical.setPadding(10, 10, 10, 10);
            txt.setWidth(width/30*14);
            txt.setHeight(180);
            distance.setTop(300);
            distance.setWidth(width / 30 * 14);
            distance.setHeight(150);
            distance.setTextSize(15);
            distance.setText("Distance: " + extras.getStringArrayList("distanceslist").get(i));
            distance.setTextColor(Color.parseColor("#304156"));
            distance.setTypeface(null, Typeface.BOLD);
            distance.setTypeface(typeface2);
            txt.setTextSize(20);
            txt.setText(extras.getStringArrayList("names").get(i));
            txt.setTypeface(null, Typeface.BOLD);
            txt.setTextColor(Color.parseColor("#304156"));
            txt.setTypeface(typeface1);
            vertical.addView(txt);
            vertical.addView(distance);
            horizontal.addView(imageView);
            horizontal.addView(vertical);
            cardView.setCardElevation(450);
            cardView.setRadius(50);
            cardView.addView(horizontal);
            cardView.setContentPadding(0, 0, 0, 12);
            layout.addView(cardView);
        }

        back.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                ItineraryActivity.super.onBackPressed();
            }
        });
    }
}