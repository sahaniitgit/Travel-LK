//package com.example.testinggraphapi;
//
//import android.content.Context;
//import android.database.sqlite.SQLiteDatabase;
//import android.database.sqlite.SQLiteOpenHelper;
//import android.os.Build;
//import android.widget.Toast;
//
//import androidx.annotation.Nullable;
//import androidx.annotation.RequiresApi;
//
//import java.io.FileOutputStream;
//import java.io.InputStream;
//import java.io.OutputStream;
//
//public class MyDatabaseHelper extends SQLiteOpenHelper {
//    Context context;
//    String dbNAme;
//    String dbPath;
//    private static final String DATABASE_NAME = "Location_DB.db";
//    private static final int DATABASE_VERSION = 1;
//
//
//
//    //@RequiresApi(api = Build.VERSION_CODES.Q)
//    public MyDatabaseHelper(remoteimageanalysis context, String name, int version) {
//        super(context, name, null, version);
//        this.dbNAme = name;
//        this.context = context;
//
//        this.dbPath = "/data/data" + context.getOpPackageName() + "/databases/";
//
//
//    }
//
//    @Override
//    public void onCreate(SQLiteDatabase db) {
//
//    }
//
//    @Override
//    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
//
//    }
////    public void CopyDatabase(){
////        try{
////            String path = dbPath + dbNAme;
////            SQLiteDatabase.openDatabase(path,null,0);
////
////        }catch (Exception e){
////            this.getReadableDatabase();
////
////        }
////
////    }
//    public void CheckDatabase(){
//        try{
//            String path = dbPath+dbNAme;
//            SQLiteDatabase.openDatabase(path,null,0);
//
//        }catch (Exception e){
//            this.getReadableDatabase();
//        }
//    }
//    public  void CopyDatabse(){
//        try {
//            InputStream io = context.getAssets().open(dbNAme);
//
//            String oufilename= dbPath+dbNAme;
//            OutputStream outputStream = new FileOutputStream(oufilename);
//            int length;
//
//            byte [] buffer = new byte [1024];
//            while ((length = io.read(buffer))>0){
//                outputStream.write(buffer,length,0);
//            }
//            io.close();
//            outputStream.flush();
//            outputStream.close();
//        }catch (Exception e){
//
//        }
//
//    }
//    public  void OpenDatabase(){
//        String path = dbPath + dbNAme;
//
//        SQLiteDatabase.openDatabase(path,null,0);
//
//    }
//}
